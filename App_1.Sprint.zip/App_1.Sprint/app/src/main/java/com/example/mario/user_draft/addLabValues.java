package com.example.mario.user_draft;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;



public class addLabValues extends Activity {

    EditText Abkuerzung;
    EditText NameB;
    EditText Beschreibung;
    EditText Einheit;
    EditText NormalRangeLow;
    EditText NormalRangeUpp;
    MyDBHelper dbHelper;
    Spinner GeschlechtB;
    Spinner Altersgruppe;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_lab_values);
        dbHelper = new MyDBHelper(this, null, null, 1);

        GeschlechtB = findViewById(R.id.spinnerGender);
        ArrayAdapter<CharSequence> adapter =ArrayAdapter.createFromResource(this,R.array.genderSpinner,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        GeschlechtB.setAdapter(adapter);

        Altersgruppe = findViewById(R.id.spinnerAgeGroup);
        ArrayAdapter<CharSequence> adapter1 =ArrayAdapter.createFromResource(this,R.array.ageGroupSpinner,android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Altersgruppe.setAdapter(adapter1);

        Abkuerzung = (EditText)findViewById(R.id.editShortcut);
        NameB = (EditText)findViewById(R.id.editName);
        Beschreibung = (EditText)findViewById(R.id.editDescription);
        Einheit = (EditText)findViewById(R.id.editUnit);
        NormalRangeLow = (EditText)findViewById(R.id.editNormRangeLow);
        NormalRangeUpp = (EditText)findViewById(R.id.editNormRangeUpp);
    }

    public void buttonAddLabValueClicked (View view){
        //LabValues lab_Values = new LabValues(Abkuerzung.getText().toString(), NameB.getText().toString(), Beschreibung.getText().toString(), Altersgruppe.getSelectedItem().toString(), GeschlechtB.getSelectedItem().toString(), NormalRangeLow.getText().toString(), NormalRangeUpp.getText().toString(), Einheit.getText().toString());
        LabValues lab_Values = new LabValues(Abkuerzung.getText().toString(), NameB.getText().toString(), Beschreibung.getText().toString(), Altersgruppe.getSelectedItem().toString(), GeschlechtB.getSelectedItem().toString(), 12, 12, Einheit.getText().toString());
        dbHelper.addValues(lab_Values);

    }

}
