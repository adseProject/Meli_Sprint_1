package com.example.mario.user_draft;

public class Relationstabelle {
    private int _id;
    private String _blutID;
    private String _userID;
    private String _blutWert;
    private String _datum;

    public Relationstabelle(String blutID, String userID, String blutWert, String datum) {
        this._blutID = blutID;
        this._userID = userID;
        this._blutWert = blutWert;
        this._datum = datum;
    }

    public int get_id() {
        return _id;
    }

    public String get_blutID() {
        return _blutID;
    }

    public String get_userID() {
        return _userID;
    }

    public String get_blutWert() {
        return _blutWert;
    }

    public String get_datum() {
        return _datum;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public void set_blutID(String _blutID) { this._blutID = _blutID; }
    public void set_userID(String _userID) { this._userID = _userID; }
    public void set_blutWert (String _blutWert) { this._blutWert = _blutWert; }
    public void set_datum (String _datum) { this._datum = _datum; }


}
