package com.example.mario.user_draft;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;
import java.util.List;

public class MeliTest extends Activity {

    //Variablen
    private EditText text;
    private TextView valuesText;
    private Button getValuesBtn;
    private MyDBHelper dbHelper;
    private String kategorie;
    private EditText datum;
    private EditText blutwert;
    private ListView listView;


    //Beim Erstellen der Activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_blood_values); //Weist der Activity ein XML-File zu

        //Weist grafische Objekte den Variablen zu
        valuesText = (TextView) findViewById(R.id.textView_BloodValues);
        getValuesBtn = (Button) findViewById(R.id.button_addBloodValue);
        listView = (ListView) findViewById(R.id.listView_blutkategorie);
        blutwert = (EditText) findViewById(R.id.editText_blutwert);
        datum = (EditText) findViewById(R.id.editText_blutwert_datum);

        //erstellt einen DBHelper, mit dem wir auf Datenbanken zugreifen können
        dbHelper = new MyDBHelper(this, null, null, 0); //Objekt erstellen

        fillListView();

        //Macht Liste klickbar
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                kategorie = listView.getItemAtPosition(position).toString();
                listView.setVisibility(View.INVISIBLE);
            }
        });
    }

    //wird zu Beginn aufgerufen um Liste
    public void fillListView() {
        fillLabValuesDatabase();
        Cursor c = dbHelper.getAllData2();
        if (c.getCount() == 0) {
            Toast.makeText(this, "Nichts", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (c.moveToNext()) {
            buffer.append(c.getString(2) + "\n\n");
        }
        String data = buffer.toString();
        String[] t = data.split("\n\n");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, t);
        listView.setAdapter(adapter);
    }

    //Nur profisorisch um Inhalt in LabValues zu simulieren, bitte entfernen
    public void fillLabValuesDatabase() {
        dbHelper.clearTable2();
        LabValues values = new LabValues("1", "Leukozyten", "1", "11", "1", 0, 0, "1");
        dbHelper.addValues(values);
        values = new LabValues("2", "Thrombozyten", null, null, null, 0, 0, null);
        dbHelper.addValues(values);
    }

    // Sobald Button geklickt
    public void getValuesBtnClicked(View view) {
        String datumValue = datum.getText().toString();
        String blutwertValue = blutwert.getText().toString();
        if (datumValue.equals("") || blutwertValue.equals("")) {
            Toast.makeText(this, "Bitte Alles Eintragen", Toast.LENGTH_SHORT).show();
        } else {
            fillRelationDatabase(datumValue, blutwertValue);
            getValuesFromDB();
        }
    }


    public void fillRelationDatabase(String datum, String blutwert) {
        //Hier lesen wir die BloodID aus, die der Gewählten Blutkategorie entspricht
        Cursor c = dbHelper.findBloodIDbyName(kategorie);
        if (c.getCount() == 0) {
            Toast.makeText(this, "Nichts", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (c.moveToNext()) {
            buffer.append(c.getString(0));
        }
        String data = buffer.toString();//Unsere BloodID

        //Wir erstellen einen neuen Eintrag und lesen diesen ein
        Relationstabelle relationDB = new Relationstabelle(data, "Hans", blutwert, datum);
        dbHelper.addRelation(relationDB);
    }

    public void getValuesFromDB() {
        Cursor c = dbHelper.getAllData3();//Alle Daten aus Relationstabelle auslesen
        if (c.getCount() == 0) {
            valuesText.setText("Nichts");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        c.moveToLast(); //wir wollen nur den letzten Eintrag anzeigen
        buffer.append("Name :" + c.getString(1) + "\n");
        buffer.append("BlutID :" + c.getString(2) + "\n");
        buffer.append("BlutKategorie :" + kategorie + "\n"); //Nur zum Anzeigen
        buffer.append("Blutwert :" + c.getString(3) + "\n");
        buffer.append("Datum :" + c.getString(4) + "\n");

        String all_values = buffer.toString();
        valuesText.setText(all_values); //wir befüllen unser Textfeld
    }

    /*
    public void showID() {
        List<Relationstabelle> ID = new LinkedList<Relationstabelle>();
        ID = db.getAllID();
        TextView ansicht = (TextView) findViewById(R.id.textView1);
        String text = ID.toString();
        ansicht.setText(text.toCharArray(), 0, text.length());
    }
    */


}
