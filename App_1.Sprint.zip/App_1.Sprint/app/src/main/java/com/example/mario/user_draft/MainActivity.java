package com.example.mario.user_draft;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
    Button createProfileBtn;
    Button selectProfileBtn;
    Button addDataButton;
    Button addBloodValueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createProfileBtn = (Button) findViewById(R.id.createButton);
        selectProfileBtn = (Button) findViewById(R.id.selectButton);
        addDataButton = (Button) findViewById(R.id.addDataButton);
        addBloodValueButton = (Button) findViewById(R.id.addBloodValueButton);

    }
    public void openCreateProfileActivity(){
        Intent intent = new Intent(this, CreateProfileActivity.class);
        startActivity(intent);
    }
    public void openDisplayProfileActivity(){
        Intent intent = new Intent(this, displayProfile.class);
        startActivity(intent);
    }

    public void openaddLabValues(){
        Intent intent = new Intent (this, addLabValues.class);
        startActivity(intent);
    }

    public void openaddBloodValues(){
        Intent intent = new Intent (this, MeliTest.class);
        startActivity(intent);
    }
    
    public void addDataButtonClicked(View view){
        openaddLabValues();
    }

    public void addBloodValueButtonClicked(View view){
        openaddBloodValues();
    }

    public void selectButtonClicked(View view) {
        openDisplayProfileActivity();
    }

    public void createButtonClicked(View view) {
        openCreateProfileActivity();
    }
}
