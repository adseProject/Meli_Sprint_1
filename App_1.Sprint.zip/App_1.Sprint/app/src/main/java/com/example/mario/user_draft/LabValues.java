package com.example.mario.user_draft;

public class LabValues {

    private int idb;
    private String sc;
    private String name;
    private String description;
    private String ageGroup;
    private String gender;
    private double normRangeLow;
    private double normRangeUpp;
    private String unit;

    //Constructor


    public LabValues(String sc, String name, String description, String ageGroup, String gender, double normRangeLow, double normRangeUpp, String unit) {
        //this.idb = idb;
        this.sc = sc;
        this.name = name;
        this.description = description;
        this.ageGroup = ageGroup;
        this.gender = gender;
        this.normRangeLow = normRangeLow;
        this.normRangeUpp = normRangeUpp;
        this.unit = unit;
    }

    //public int getIdb() {
    //    return idb;
    //}

    //public void setIdb(int idb) {
    //    this.idb = idb;
    //}

    public String getSc() {
        return sc;
    }

    public void setSc(String sc) {
        this.sc = sc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public double getNormRangeLow() {
        return normRangeLow;
    }

    public void setNormRangeLow(double normRangeLow) {
        this.normRangeLow = normRangeLow;
    }

    public double getNormRangeUpp() {
        return normRangeUpp;
    }

    public void setNormRangeUpp(double normRangeUpp) {
        this.normRangeUpp = normRangeUpp;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
}